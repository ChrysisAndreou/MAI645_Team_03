indian framerate 120
salsa  framerate 60
martial framerate 120
